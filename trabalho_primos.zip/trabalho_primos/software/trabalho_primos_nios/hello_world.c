//#define _NIOS2_ 1
#define _ATMEGA_ 1

#ifdef _NIOS2_

////////////////////////////////////////////////
//NIOS2

#include "system.h"
#include "altera_avalon_pio_regs.h"

#include "sys/alt_stdio.h"
#include "alt_types.h"

//biblioteca para usar a fun��o de atraso em microsegundos
//fun��o => usleep("tempo_us")
#include <unistd.h>

void atraso_ms(alt_u16 tempo);
void setup_hard(void);
void setup(void);
void loop(void);

//Comandos para leitura e escrita nas portas IO
#define PORT(local)		IORD_ALTERA_AVALON_PIO_DATA(local)
#define LAT(local, dado)	IOWR_ALTERA_AVALON_PIO_DATA(local, dado)

void atraso_ms(alt_u16 tempo) {

	alt_u16 i;

    for (i=0; i<tempo; i++) usleep(1000);
}

void setup_hard(void) {
    setup();
}




//NIOS2
////////////////////////////////////////////////////////////////

#endif

#ifdef _ATMEGA_
///////////////////////////////////////////
//ATMEGA2560



//RELACAO DAS PORTAS DO ATMEGA COM AS PORTAS DO NIOS2
//porta A -> 10
//porta B -> 20
//porta C -> 30
//porta D -> 40
//porta E -> 50
//porta F -> 60
//porta G -> 70
//porta H -> 80
//porta L -> 90

#define KEY_JD_BASE 90 //porta de entrada; esta relacionada com a porta L (button)
#define HEX76_JD_BASE 40 //porta de saida; esta relacionada com a porta D (display 7 seg)
#define HEX54_JD_BASE 50 //porta de saida; esta relacionada com a porta E (display 7 seg)

//PORT le a entrada e define o valor da sa�da de uma porta
//LAT escreve o valor na porta

//PIO le a entrada
//PORT

#include<avr/io.h>

#define F_CPU 1000000UL
#include<util/delay.h>

//RELACAO DE TIPOS NIOS2 ATMEGA
#define alt_u8 uint8_t
#define alt_u16 uint16_t

//alt_u8 e o tipo da variavel

unsigned char dd=3, du=4;

void atraso_ms(alt_u16 tempo);
void LAT(alt_u8 local, alt_u8 dado);
alt_u8 PORT(alt_u8 local);
void setup_hard (void);
void setup(void);
void loop(void);
void dec2dig (alt_u8 num, alt_u8 *tot);
void hex2dig (alt_u8 num, alt_u8 *tot1);
alt_u8 seq_primos_cresc (alt_u8 estado);
alt_u8 seq_primos_decresc (alt_u8 estado);

void atraso_ms(alt_u16 tempo) {

    for (alt_u16 i=0; i<tempo; i++) _delay_us(1000);
}

void LAT(alt_u8 local, alt_u8 dado) { //LAT e uma funcao void pois n tem saida, apenas escreve a informacao na porta

//    int num=1;

    switch (local) {
        case 10: PORTA=dado; break;
        case 20: PORTB=dado; break;
        case 30: PORTC=dado; break;
        case 40: PORTD=dado; break;
        case 50: PORTE=dado; break;
        case 60: PORTF=dado; break;
        case 70: PORTG=dado; break;
        case 80: PORTH=dado; break;
        case 90: PORTL=dado; break;
    }

}

alt_u8 PORT(alt_u8 local) { //PORT nao e uma funcao void pois tem saida

    alt_u8 dado;

    switch (local) {
        case 10: dado=PINA; break;
        case 20: dado=PINB; break;
        case 30: dado=PINC; break;
        case 40: dado=PIND; break;
        case 50: dado=PINE; break;
        case 60: dado=PINF; break;
        case 70: dado=PING; break;
        case 80: dado=PINH; break;
        case 90: dado=PINL; break;
        default: dado=0;
    }

    return dado;

}

void setup_hard(void) {

    //No atmega entrada � 0 e saida � 1
    //L � o switch e D � o led
    //E e H sao os displays 7seg

    DDRL = 0b00000000; //PORT � entrada
    PORTL = 0b11111111;

    DDRD = 0b11111111; //DDRx configura PORT como entrada ou sa�da. Nesse caso PORT � sa�da
    PORTD = 0b00000000; //1 � pull down e 0 � pull up

    DDRE = 0b11111111;
    PORTE = 0b00000000;

    setup();

}



//ATMEGA2560
/////////////////////////////////////////////

#endif

//HARDWARE
//////////////////////////////////////////////////////////
//TODAS AS ARQUITETURAS

int main(void) {
  setup_hard();
  while (1) loop();
  return 0;
}

////////////////////////////////////////////////////////////
//LOGICA

alt_u8 num = 2;
int dec = 0;

alt_u8 seq_primos_cresc (alt_u8 estado) {



    switch (estado) {

        case 2:
            estado = 3;
            break;

        case 3:
            estado = 5;
            break;

        case 5:
            estado = 7;
            break;

        case 7:
            estado = 9;
            break;

        case 9:
            estado = 11;
            break;

        case 11:
            estado = 13;
            break;

        case 13:
            estado = 17;
            break;

        case 17:
            estado = 19;
            break;

        case 19:
            estado = 23;
            break;

        case 23:
            estado = 29;
            break;

        case 29:
            estado = 31;
            break;

        case 31:
            estado = 31;
            break;

        default:
            estado = 2;

    }

    return estado;
}

alt_u8 seq_primos_decresc (alt_u8 estado) {


   switch (estado) {

        case 2:
            estado = 2;
            break;

        case 3:
            estado = 2;
            break;

        case 5:
            estado = 3;
            break;

        case 7:
            estado = 5;
            break;

        case 9:
            estado = 7;
            break;

        case 11:
            estado = 9;
            break;

        case 13:
            estado = 11;
            break;

        case 17:
            estado = 13;
            break;

        case 19:
            estado = 17;
            break;

        case 23:
            estado = 19;
            break;

        case 29:
            estado = 23;
            break;

        case 31:
            estado = 29;
            break;

        default:
            estado = 31;

    }

    return estado;
}



void dec2dig (alt_u8 num, alt_u8 *tot) {

	alt_u8 dd,du;

    du = num%10;
    dd = ((num/10)%10) << 4;
    *tot = dd + du ;



}

int counter (alt_u8 flag, alt_u8 numb){

    int maxValue = 31;
    int minValue = 2;
    alt_u8 nextNumber = numb;

    if (flag == 8){
        if (dec < 1){
            dec = 1;
            nextNumber = seq_primos_cresc(numb);
        }

    }
    else if (flag == 4){
        if(dec < 1){
            dec = 1;
            nextNumber = seq_primos_decresc(numb);
        }

    }
    else if (flag == 2){
        if(dec < 1){
            dec = 1;
            nextNumber = maxValue;
        }

    }
    else if (flag == 1){

        if(dec < 1){

            dec = 1;
            nextNumber = minValue;
        }

    }
    else{
        dec = 0;
    }


  return nextNumber;
}

void hex2dig(alt_u8 num, alt_u8 *tot1){

    alt_u8 dd,du;

    du = num%16;
    dd = ((num/16)%16) << 4;
    *tot1 = dd + du ;

}

void setup(void) {


}

void loop(void) {

	alt_u8 dado,tot,tot1;

    dado = ~PORT(KEY_JD_BASE);
    num = counter(dado,num);

    dec2dig(num,&tot);
    hex2dig(num,&tot1);
    LAT(HEX54_JD_BASE, tot);
    LAT(HEX76_JD_BASE, tot1);


       atraso_ms(10);


}
